# Cuber
Chrome Cube Lab Files

Just download the .ZIP file then go to you browser run ```index.html``` then get started!

Official project site: https://www.chrome.com/cubelab

Demo: http://seanfrasure.github.io/cuber/cuber/index.html

*If there are any questions please feel free to make a new issue*
